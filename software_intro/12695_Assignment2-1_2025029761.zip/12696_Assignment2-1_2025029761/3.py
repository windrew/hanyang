n = int(input())
for i in range(10):
    print(str(n)+'*'+str(i)+'='+str(n*i))