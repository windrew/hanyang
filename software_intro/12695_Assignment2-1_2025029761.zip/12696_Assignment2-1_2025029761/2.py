a, b, c = 10, 'hello', 3.1

print(str(a)+b+str(c))