#include <stdio.h>

int add(int x,int y);