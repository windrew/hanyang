#include <stdio.h>

typedef struct
{
    int xpos;
    int ypos;
} Point;
