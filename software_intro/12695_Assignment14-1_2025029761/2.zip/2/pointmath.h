#include <stdio.h>
#include "point.h"

Point* getScale2xPoint(const Point* a);