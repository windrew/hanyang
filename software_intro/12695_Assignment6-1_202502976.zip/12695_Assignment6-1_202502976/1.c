#include <stdio.h>

int main()
{
    int a = 10;
    char b[6] = "hello";
    double c = 3.1;
    printf("%d%s%.1lf",a,b,c);
}