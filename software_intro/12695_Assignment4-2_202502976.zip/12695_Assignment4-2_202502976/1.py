d = dict()
a = input().split()

for i in a:
    if i not in d:
        d[i] = 1
    else:
        d[i] += 1

key = d.keys()

for i in key:
    print(i+":",d[i])