cars = input("Number of cars:\n")
buses = input("Number of buses:\n")
vehicles = int(cars) + int(buses)
print("Number of vehicles:",vehicles)
