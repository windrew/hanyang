x = int(input("x:\n"))
a = int(input("*a\n"))
b = int(input("/b\n"))
c = int(input("+c\n"))
d = int(input("-d\n"))

print(x,"*",a,"/",b,"+",c,"-",d,"=",x*a/b+c-d)10