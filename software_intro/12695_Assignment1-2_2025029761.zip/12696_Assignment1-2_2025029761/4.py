a = input()
b = input()
c = input()

d = float(input())
e = float(input())
f = float(input())

print(a+b+c)
print(d+e+f)