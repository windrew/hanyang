a = str(input())

if a[0] == 'a' or a[0] == 'b' or a[0] == 'c':
    a = a.upper()
else:
    a = a.lower()

print(a)