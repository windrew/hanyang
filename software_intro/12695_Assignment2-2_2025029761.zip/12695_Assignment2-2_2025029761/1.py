n = 1
s = 0
while n != 0:
    n = int(input())
    s += n
print("sum:",s)